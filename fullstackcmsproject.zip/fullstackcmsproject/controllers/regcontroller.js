const regTable=require('../models/reg')
require('dotenv').config()
const nodemailer=require('nodemailer')
const bcrypt=require('bcrypt')
const jwt=require('jsonwebtoken')


exports.singupform=(req,res)=>{
    res.render('signupform.ejs',{message:''})
}
  

exports.usercreate=async(req,res)=>{
    try{
    const{fname,lname,email,dob,mob,pass,gender}=req.body
    const conpass=await bcrypt.hash(pass,10)
    
    const data=await regTable.findOne({email:email})
    if(data==null){
    const newdata=new regTable({email:email,password:conpass,firstname:fname,lastname:lname,mobile:mob,dob:dob,gender:gender})
    newdata.save()
    const newuserid=newdata.id

    const transporter = nodemailer.createTransport({
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          user: "fullstacktest123@gmail.com",
          pass: "pienyyeholrmadwg",
        },
    });

    const info=await transporter.sendMail({
        from:"fullstacktest123@gmail.com",
        to: email, 
        subject:"Account Verfication link: fullstack project",
        text: "Hello",  
        // attachments:[{
        //   path:filepath
        // }]
         html: `<a href='http://localhost:5000/emailverify/${newuserid}'>Click TO Active Account</a>`, 
      });

    res.render('signupform.ejs',{message:'User Is Succesfuly Create!! Please check your email form verfication link'})
}else{
    res.render('signupform.ejs',{message:'email is already regsitered'})
}
}catch(error){
    console.log(error.message)
}
}


exports.emailverfiy=async(req,res)=>{
    const id=req.params.id
   await regTable.findByIdAndUpdate(id,{status:'Active'})
   res.render('message.ejs',{message:'Accound has been Active'})
}


exports.login=(req,res)=>{
    res.render('login.ejs',{message:''})
 }
  
 exports.logincheck=async(req,res)=>{
    const{us,Password}=req.body
    const usercheck=await regTable.findOne({email:us})
    // console.log(Password,usercheck.password)
    // console.log(usercheck)
     if(usercheck!=null){
      const passcompare=await bcrypt.compare(Password,usercheck.password)
      if(passcompare){
        if(usercheck.status=='Active'){
           req.session.Auth=true
           req.session.loginname=us
           if(usercheck.email=='admin@gmail.com'){
            res.redirect('admin/dashboard')
           }else{
            res.redirect('/allblogs')
           }
        //   req.session.firstname=usercheck.firstname
        //    req.session.sub=usercheck.subscription
        //    res.redirect('/allblogs')
        }else{
            res.render('login.ejs',{message:'Your account is unactive. To active it, go to gmail'})
        }
        }else{
        res.render('login.ejs',{message:'Wrong Password'})
      }

    }else{
        res.render('login.ejs',{message:'Wrong Username/Email'})
    } 
 }   

 exports.forgot=(req,res)=>{
    res.render('forgot.ejs',{message:''})
}



exports.forgotlink=async(req,res)=>{
    const{email}=req.body
    const verifyemail=await regTable.findOne({email:email})
     if(verifyemail!=null){
    let payload={username:verifyemail.email}
    const token=jwt.sign({payload},process.env.SKEY,{expiresIn:'35s'})
    console.log(token)
        const transporter = nodemailer.createTransport({
            host: "smtp.gmail.com",
            port: 465,
            secure: true,
            auth: {
              user: "fullstacktest123@gmail.com",
              pass: "pienyyeholrmadwg",
            },
        });
        console.log('smtp cnnt..')
        await transporter.sendMail({
            from:"fullstacktest123@gmail.com",
            to: email, 
            subject:"Forgot Password link",
            text: "Hello",  
            // attachments:[{
            //   path:filepath
            // }]
            html: `<a href=http://localhost:5000/forgotpasswordlink/${verifyemail.id}/${token}>Click TO change Passwords</a>`, 
          });
          res.render('forgot.ejs',{message:'Forgot link has been send to your email Id!'})
     }else{
        res.render('forgot.ejs',{message:'Email not regsiterded with us!!'})
     }
}

exports.forgotlink1=(req,res)=>{
    let=message=''
    const id=req.params.id
    const token=req.params.gg
    if(token){
       jwt.verify(token,process.env.SKEY,(error,user)=>{
        if(error){
            message='Your forgot link has been experied'
            res.render('autexpired.ejs',{message})
        }
    else{
        res.render('forgotpasswordform.ejs',{message})
    }})
    
}}

exports.forgotpasswordupdate=async(req,res)=>{
    const id=req.params.id
    const{npass,cpass}=req.body
    if(npass==cpass){
        const bpass=await bcrypt.hash(npass,10)
        await regTable.findByIdAndUpdate(id,{password:bpass})
        res.render('forgotmessage.ejs')
    }else{
        res.render('forgotpasswordform.ejs',{message:'Password Not Matched'})
    }
    
}


exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}


exports.changepasswordform=(req,res)=>{
    const loginname=req.session.loginname
   res.render("changepasswordform.ejs",{loginname,message:''})
}
exports.changepassword=async(req,res)=>{
    let message=''
    const{cpass,npass,copass}=req.body
    const newpass=await bcrypt.hash(npass,10)
    const loginname=req.session.loginname
    const userdata= await regTable.findOne({email:loginname})
    // console.log(userdata)
    const copmarepass=await bcrypt.compare(cpass,userdata.password)
    // console.log(copmarepass)
    if(npass==copass){
        if(copmarepass){
            await regTable.findByIdAndUpdate(userdata.id,{password:newpass})
            message='Successfully Password has been changed'
            req.session.destroy()
            res.render('changepasswordmessage.ejs') 
           
           }else{
               message='Current password not matched'
               res.render('changepasswordform',{loginname,message})
           }
    }else{
       message='password not matched!!'
       res.render('changepasswordform',{loginname,message}) 
    }
    
}


exports.profileform=async(req,res)=>{
    const message=req.params.mess
    const loginname=req.session.loginname
    const data=await regTable.findOne({email:loginname})
    res.render('profileform.ejs',{loginname,data,message})
}

exports.profileupdate=async(req,res)=>{
    const{fname,lname,gender}=req.body 
    const id=req.params.id
    await regTable.findByIdAndUpdate(id,{firstname:fname,lastname:lname,gender:gender})
    res.redirect('/profile/Successfuly update')
}  