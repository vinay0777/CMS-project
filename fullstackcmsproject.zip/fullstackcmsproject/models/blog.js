const mongoose=require('mongoose')



const blogSchema=mongoose.Schema({
   title:{
    type:String,
    required:true
   },
   quotes:{
    type:String,
    required:true
   },
   user:{
    type:String,
    required:true
   },
   postedDate:{
    type:Date,
    required:true,
    default:new Date().toString()
   },
   img:{
      type:String,
   }
})

module.exports=mongoose.model('blog',blogSchema)