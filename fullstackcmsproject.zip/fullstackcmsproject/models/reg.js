const mongoose=require('mongoose')

const regSchema=mongoose.Schema({
    email:{
        type:String,
        required:true,
        unique:true
    },
    password:{
        type:String,
        required:true
    },
    firstname:{
        type:String
    },
    lastname:{
        type:String
    },
    mobile:{
        type:Number
    },
    gender:{
        type:String
    },
    dob:{
        type:Date,
    },
    createDate:{
        type:Date,
        default:new Date()
    },
    status:{
        type:String,
        default:'Suspended',
        required:true
    }
    // subscription:{
    //    type:String,
    //    default:'nosubscription',
    //    required:true
    // }

})

module.exports=mongoose.model('reg',regSchema)

