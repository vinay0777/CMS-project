const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const blogc=require('../controllers/blogcontroller')
const logincheck=require('../milddleware/logincheck')
const upload=require('../milddleware/multer')
const subscription = require('../milddleware/subscription')


router.get('/',regc.login)
router.post('/',regc.logincheck)
router.get('/signup',regc.singupform)
router.post('/signup',regc.usercreate)
router.get('/emailverify/:id',regc.emailverfiy)
router.get('/allblogs',logincheck,blogc.allblogs)
router.get('/logout',regc.logout)

router.get('/forgot',regc.forgot)
router.post('/forgot',regc.forgotlink)
router.get('/forgotpasswordlink/:id/:gg',regc.forgotlink1)
router.post('/forgotpasswordlink/:id',regc.forgotpasswordupdate)
router.get('/myblogs/:mess',logincheck,blogc.myblogs)
router.get('/addblog',logincheck,blogc.blogform)
router.post('/addblog',upload.single('img'),logincheck,blogc.blogadd)
router.get('/blogdelete/:id',blogc.blogdelete)
router.get('/blogupdate/:id',logincheck,blogc.blogupdate)
router.post('/blogupdate/:id',upload.single('img'),blogc.blogupdateform)
router.get('/changepasswordform',logincheck,regc.changepasswordform)
router.post('/changepasswordform',regc.changepassword)
router.get('/profile/:mess',logincheck,regc.profileform)
router.post('/profile/:id',regc.profileupdate)



module.exports=router